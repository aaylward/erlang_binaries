-module(older).

-export([none/0]).

none() ->
    old.
