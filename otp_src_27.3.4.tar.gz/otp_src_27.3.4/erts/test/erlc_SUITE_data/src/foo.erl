-module foo.

-export [foo/0].

foo() ->
    ['while', 'until'].
