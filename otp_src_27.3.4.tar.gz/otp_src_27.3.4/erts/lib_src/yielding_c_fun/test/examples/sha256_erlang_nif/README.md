sha256_nif
=====

An OTP library that illustrates how one can implement a yielding
Erlang NIF API with the help of Yielding C Fun.

Build
-----

    $ rebar3 compile

or

    $ make

Test
----

    $ rebar3 ct

or

    $ make test