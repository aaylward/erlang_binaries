#include <stdint.h>
#include <stdlib.h>

void calc_sha_256(uint8_t hash[], const void *input, size_t len);
